package com.employee.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.model.Employee;
import com.employee.repository.EmployeeRepo;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepo employeeRepo;

	public String createEmployee(Employee employee) {
		try {
			employeeRepo.save(employee);
			return "New Employee created";
		} catch (Exception e) {
			System.out.println("Exception occured");
			return e.getMessage();
		}
	}

	public Employee getTax(String employeeId) {
		Double tax = null;
		Employee resultemployee = null;
		try {
			Optional<Employee> employee = employeeRepo.findById(employeeId);
			if (employee.isPresent()) {
				resultemployee = employee.get();
				Integer perMonthSalary = resultemployee.getSalary();
				Integer ctc = perMonthSalary * 12;
				Integer perdaySalary = perMonthSalary / 30;
				if (ctc < 250000) {
					resultemployee.setTax(0.0);
				} else {
					if (ctc > 250000 && ctc < 500000) {
						int x = ctc - 250000;
						resultemployee.setTax(x * 0.05);
					} else if (ctc >= 500000 && ctc <= 1000000) {
						int y = ctc - 500000;
						if (y == 0)
							resultemployee.setTax(12500.0);
						else
							resultemployee.setTax(y * 0.1 + 12500.0);

					} else {
						int z = ctc - 1000000;
						resultemployee.setTax(z * 0.2 + 12500.0 + 50000.0);
					}
				}

				if (ctc > 2500000) {
					double cess = (ctc - 2500000) * 0.02;
					resultemployee.setCess(cess);
				}
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				Date doj = sdf.parse(resultemployee.getDOJ());
				Date newFYdate = sdf.parse("04/01/2022");

				long timeDiff = Math.abs(newFYdate.getTime() - doj.getTime());
				int daysDiff = (int) (TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS));
				Integer lossOfPay = daysDiff * perdaySalary;
				Integer totalSalary = ctc - lossOfPay;
				resultemployee.setTotalSalary(totalSalary);

			}
			System.out.println("No Records Found");
		} catch (Exception e) {
			System.out.println("Exception occured");
		}
		return resultemployee;
	}
}
